Year of Birth: 2003
Height: 168 cm
Weight: 60 kg
Leg Length: 92 cm
